angular.module('angularJSKurs')
    .controller('HomeController', function ($scope) {
        $scope.title = 'Home Page';
    })